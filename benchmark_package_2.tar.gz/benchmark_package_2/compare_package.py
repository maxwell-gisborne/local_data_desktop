#!/usr/bin/env python3
"""Compare Vincent JSON or console results against either finalized package.

python compare_package.py benchmark_package_1 vincent_results.txt --series grid_zero_field --text-unit S
Dependencies: Python 3.10+ and NumPy. No project imports or numerical recomputation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from pathlib import Path

import numpy as np


class Package:
    def __init__(self, folder):
        self.folder = folder
        self.units = read_json(folder / 'units_context.json')
        self.dimensions = read_json(folder / 'dimensions.json')

    def scale(self, dimension):
        return math.prod(float(self.units[base]['scale_to_si'])**power
                         for base, power in self.dimensions[dimension].items())


def read_json(path):
    with Path(path).open() as stream:
        return json.load(stream)

def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")

def compare(actual, expected, package, rtol):
    failures, count = [], 0
    def walk(a, e, path='', field=None):
        nonlocal count
        if isinstance(e, dict):
            if not isinstance(a, dict) or set(a) != set(e):
                failures.append(dict(path=path, reason='object keys differ')); return
            for k in e:
                # Textual descriptions are not numerical validation inputs.
                if k in ('conventions', 'schema', 'dimensions', 'unit_context', 'dimension_registry'):
                    if k != 'conventions' and a[k] != e[k]:
                        failures.append(dict(path=path+'.'+k, reason='metadata differs'))
                    continue
                walk(a[k], e[k], path+'.'+k, k)
        elif isinstance(e, list):
            if not isinstance(a, list) or len(a) != len(e):
                failures.append(dict(path=path, reason='array lengths differ')); return
            if e and all(isinstance(v, dict) for v in e):
                keys = ('label',) if 'label' in e[0] else (('coarse_N', 'fine_N') if 'coarse_N' in e[0] else ('N', 'band'))
                def keyed(items):
                    out = {}
                    for item in items:
                        key = tuple(item[k] for k in keys)
                        if key in out:
                            raise ValueError(f'Duplicate result key at {path}: {key}')
                        out[key] = item
                    return out
                aa, ee = keyed(a), keyed(e)
                if set(aa) != set(ee):
                    failures.append(dict(path=path, reason='run/grid keys differ')); return
                for key in ee:
                    walk(aa[key], ee[key], f'{path}[{key}]', field)
            else:
                for i, (av, ev) in enumerate(zip(a, e)):
                    walk(av, ev, f'{path}[{i}]', field)
        elif isinstance(e, (float, int)) and not isinstance(e, bool):
            count += 1
            dimension = EXPECTED_DIMENSIONS.get(field)
            scale = package.scale(dimension) if dimension else 1.0
            av, ev = float(a)*scale, float(e)*scale
            atol = {'SHEET_CONDUCTANCE': 1e-12, 'ENERGY': 1e-30}.get(dimension, 1e-12)
            tolerance = (1e-12 * abs(ev) if field in ('N', 'coarse_N', 'fine_N', 'band', 'field', 'mu', 'temperature', 'tau') else atol+rtol*abs(ev))
            if not math.isfinite(av) or not math.isfinite(ev) or abs(av-ev) > tolerance:
                failures.append(dict(path=path, actual=a, expected=e,
                                     absolute_error_si=abs(av-ev), tolerance_si=tolerance))
        elif a != e:
            failures.append(dict(path=path, reason='value differs', actual=a, expected=e))
    walk(actual, expected)
    return dict(passed=not failures, numeric_values_checked=count, failures=failures,
                rtol=rtol, conductivity_atol_S=1e-12, energy_atol_J=1e-30,
                other_atol_si=1e-12)

def compare_console(text, expected, package, rtol, series):
    """Compare console TOTAL tensors in S; never invent missing run parameters."""
    number = r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?'
    header = re.compile(r'^\s*===\s+(.+?)\s+===\s*$', re.MULTILINE)
    total = re.compile(
        r'^\s*TOTAL\s*:\s*sigma\s*=\s*\[\[\s*('+number+r')\s*,\s*('+number+r')'
        r'\s*\]\s*,\s*\[\s*('+number+r')\s*,\s*('+number+r')'
        r'\s*\]\]\s*trace\s*=\s*('+number+r')\s*$', re.MULTILINE)
    def rounding(token):
        if float(token) == 0:
            return 0.0
        mantissa, _, exponent = token.lower().partition('e')
        decimals = len(mantissa.partition('.')[2])
        return 0.5 * 10.0**(int(exponent or '0') - decimals)
    matches = list(header.finditer(text))
    parsed = {}
    for i, h in enumerate(matches):
        label = h.group(1)
        end = matches[i+1].start() if i+1 < len(matches) else len(text)
        block = text[h.end():end]
        totals = list(total.finditer(block))
        if len(totals) != 1:
            raise ValueError(f'{label}: expected exactly one parseable TOTAL line')
        if label in parsed:
            raise ValueError(f'Duplicate run label: {label}')
        tokens = totals[0].groups()
        parsed[label] = (np.array([float(t) for t in tokens]),
                         np.array([rounding(t) for t in tokens]))
    if not parsed:
        raise ValueError('No run headers and TOTAL tensors found in console text')
    if len(re.findall(r'^\s*TOTAL\s*:', text, re.MULTILINE)) != len(parsed):
        raise ValueError('Unassociated or malformed TOTAL line')
    groups = {}
    for key, value in expected.items():
        if isinstance(value, dict) and 'sigma' in value and 'label' in value:
            groups[key] = [value]
        elif isinstance(value, list) and value and all(isinstance(v, dict) and 'sigma' in v for v in value):
            groups[key] = value
    selected = series or list(groups)
    if len(selected) != len(set(selected)) or any(s not in groups for s in selected):
        raise ValueError(f'Choose distinct series from: {list(groups)}')
    wanted = {run['label']: run for group in selected for run in groups[group]}
    missing = sorted(set(wanted) - set(parsed))
    unexpected = sorted(set(parsed) - set(wanted))
    failures = []
    if missing:
        failures.append(dict(reason='missing run labels', labels=missing))
    if unexpected:
        failures.append(dict(reason='unexpected run labels', labels=unexpected))
    rows = []
    count = 0
    scale = package.scale('SHEET_CONDUCTANCE')
    fields = ['sigma_xx', 'sigma_xy', 'sigma_yx', 'sigma_yy', 'trace']
    for label, run in wanted.items():
        if label not in parsed:
            continue
        actual, quantum = parsed[label]
        reference = np.array([*np.asarray(run['sigma']).reshape(-1), run['trace']]) * scale
        delta = actual - reference
        tolerance = 1e-12 + rtol*np.abs(reference) + quantum
        for i, name in enumerate(fields):
            count += 1
            if not np.isfinite(actual[i]) or abs(delta[i]) > tolerance[i]:
                failures.append(dict(label=label, field=name, actual_S=float(actual[i]),
                                     expected_S=float(reference[i]), difference_S=float(delta[i]),
                                     tolerance_S=float(tolerance[i])))
        trace_error = abs(actual[4] - actual[0] - actual[3])
        if trace_error > quantum[4] + quantum[0] + quantum[3] + 1e-12:
            failures.append(dict(label=label, reason='printed trace does not equal tensor trace'))
        rows.append(dict(label=label, actual_trace_S=float(actual[4]),
                         expected_trace_S=float(reference[4]),
                         relative_trace_difference=float(delta[4]/reference[4]) if reference[4] else None))
    report = {'passed': not failures, 'numeric_values_checked': count, 'failures': failures,
                  'format': 'vincent_console', 'conductivity_unit': 'S', 'selected_series': selected,
                  'available_series': list(groups), 'missing_labels': missing, 'unexpected_labels': unexpected,
                  'scope': 'TOTAL tensor components and trace only',
                  'unverified': ['mu', 'temperature', 'tau', 'electric field', 'per-band contributions',
                              'velocity diagnostics', 'energy consistency', 'Fermi-window diagnostics'],
                  'rtol': rtol, 'conductivity_atol_S': 1e-12,
                  'print_rounding': 'half a final printed decimal place added to each nonzero value tolerance',
                  'runs': rows}
    # Optional diagnostic: compare explicitly printed inverse-angstrom vectors.
    vectors = {}
    for index in (1, 2):
        match = re.search(r'^\s*b'+str(index)+r'\s*=\s*\[\s*('+number+r')\s+('+number+r')\s*\]\s+angstrom\^-1\s*$', text, re.MULTILINE)
        if match:
            vectors[index] = np.array([float(t) for t in match.groups()])
    if len(vectors) == 2:
        payload = read_json(package.folder / 'vincent_epsilon_all_bands.json')
        r = payload['grid_definition']['reciprocal_vectors']
        expected_b = np.array([r['b1'], r['b2']]) * package.scale('WAVEVECTOR') / 1e10
        printed = np.array([vectors[1], vectors[2]])
        match = np.allclose(printed, expected_b, rtol=1e-8, atol=1e-8)
        transpose = np.allclose(printed.T, expected_b, rtol=1e-8, atol=1e-8)
        report['printed_reciprocal_vectors'] = dict(
            match=bool(match), transpose_matches=bool(transpose),
            printed_per_angstrom=printed.tolist(), expected_per_angstrom=expected_b.tolist())
        if not match:
            report['failures'].append(dict(reason='printed reciprocal vectors differ from package',
                                           transpose_matches=bool(transpose)))
            report['passed'] = False
    return report

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def input_names():
    groups = ['reference', 'grid_zero_field'] if PROFILE == 1 else [
        'reference', 'field_magnitude_x', 'field_magnitude_diagonal', 'grid_finite_field']
    return ['dimensions.json', 'units_context.json', 'vincent_epsilon_all_bands.json',
            *[f'conductivity_{g}.json' for g in groups]]

def verify_manifest(folder):
    path = folder / 'SHA256SUMS'
    if not path.is_file():
        raise ValueError('Package is not finalized: run compute first')
    names = set()
    for line in path.read_text().splitlines():
        checksum, name = line.split('  ', 1)
        if Path(name).name != name or name in names:
            raise ValueError('Invalid checksum manifest')
        names.add(name)
        if digest(folder / name) != checksum:
            raise ValueError(f'Package checksum failed: {name}')
    required = set(input_names() + ['expected_results.json', 'calculation_metadata.json'])
    if (folder / 'build_provenance.json').is_file():
        required.add('build_provenance.json')
    if not required <= names:
        raise ValueError('Checksum manifest does not cover the reference and its inputs')

def main():
    global PROFILE, EXPECTED_DIMENSIONS
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', type=Path)
    parser.add_argument('results', type=Path)
    parser.add_argument('--series', action='append', help='console series; repeat to select several')
    parser.add_argument('--text-unit', choices=['S'], help='confirm console conductivity values are in S')
    parser.add_argument('--rtol', type=float, default=1e-7)
    args = parser.parse_args()
    if not math.isfinite(args.rtol) or args.rtol < 0:
        parser.error('rtol must be finite and nonnegative')
    folder = args.package
    expected_path = folder / 'expected_results.json'
    if args.results.resolve() == expected_path.resolve():
        raise ValueError('Results must be a different file from the reference')
    if args.results.resolve() == (folder / 'comparison_report.json').resolve():
        raise ValueError('Results path must differ from the output report path')
    expected = read_json(expected_path)
    schemas = {'dft_local.benchmark_package_1': 1, 'dft_local.benchmark_package_2': 2}
    if expected.get('schema') not in schemas:
        raise ValueError('Unsupported reference package schema')
    PROFILE = schemas[expected['schema']]
    EXPECTED_DIMENSIONS = expected['dimensions']
    verify_manifest(folder)
    package = Package(folder)
    contents = args.results.read_text()
    if contents.lstrip().startswith('{'):
        if args.series or args.text_unit:
            raise ValueError('--series and --text-unit apply to console text only')
        report = compare(json.loads(contents), expected, package, args.rtol)
    else:
        if args.text_unit != 'S':
            raise ValueError('Confirm console conductivity units with --text-unit S')
        report = compare_console(contents, expected, package, args.rtol, args.series)
        print('Scope: TOTAL tensors and trace; run parameters and other diagnostics are not verified.')
    report.update(package_profile=PROFILE, actual_file=str(args.results),
                  actual_sha256=digest(args.results), expected_sha256=digest(expected_path))
    write_json(folder / 'comparison_report.json', report)
    print(f"Comparison: {'PASS' if report['passed'] else 'FAIL'}; "
          f"{report['numeric_values_checked']} numeric values, {len(report['failures'])} mismatches")
    for failure in report['failures'][:10]:
        print(json.dumps(failure))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError, TypeError) as exc:
        print(f'Error: {exc}', file=sys.stderr)
        raise SystemExit(2)
