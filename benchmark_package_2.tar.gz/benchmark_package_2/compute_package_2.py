#!/usr/bin/env python3
"""Recompute package benchmarks using Python and NumPy only.

Run: python compute_package_2.py /path/to/benchmark_package_2
Default: writes expected_results.json and finalizes checksums.
Use the separate compare_package.py script to compare external results.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import numpy as np

PROFILE = 2
E_CHARGE = 1.602176634e-19
HBAR = 1.054571817e-34
KB = 1.380649e-23
SPIN = 1.0
EXPECTED_DIMENSIONS = {'field': 'ELECTRIC_FIELD', 'tau': 'TIME', 'mu': 'ENERGY', 'temperature': 'TEMPERATURE', 'sigma': 'SHEET_CONDUCTANCE', 'trace': 'SHEET_CONDUCTANCE'}


def read_json(path):
    with Path(path).open() as stream:
        return json.load(stream)


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def fermi_window(energy, mu, temperature):
    x = (energy - mu) / (KB * temperature)
    f = np.empty_like(x, dtype=float)
    positive = x >= 0
    t = np.exp(-x[positive])
    f[positive] = t / (1 + t)
    t = np.exp(x[~positive])
    f[~positive] = 1 / (1 + t)
    return f * (1 - f)


def velocity(energy_J, basis_per_m):
    """B contains reciprocal vectors as rows: k = q @ B."""
    n1, n2 = energy_J.shape
    dq = np.stack([
        (np.roll(energy_J, -1, axis=0) - np.roll(energy_J, 1, axis=0)) * n1 / 2,
        (np.roll(energy_J, -1, axis=1) - np.roll(energy_J, 1, axis=1)) * n2 / 2,
    ], axis=-1)
    return np.einsum('...i,ij->...j', dq, np.linalg.inv(basis_per_m.T)) / HBAR


def sample(grid, q):
    """Periodic bilinear sampling of a scalar grid."""
    n1, n2 = grid.shape
    x = np.mod(q[..., 0], 1) * n1
    y = np.mod(q[..., 1], 1) * n2
    i = np.floor(x).astype(int) % n1
    j = np.floor(y).astype(int) % n2
    ip, jp = (i + 1) % n1, (j + 1) % n2
    tx, ty = x - np.floor(x), y - np.floor(y)
    return ((1-tx)*(1-ty)*grid[i, j] + tx*(1-ty)*grid[ip, j]
            + (1-tx)*ty*grid[i, jp] + tx*ty*grid[ip, jp])


def conductivity_band(energy_J, v, basis_per_m, mu, temperature, tau, field, order):
    """Eq. 8.30 convention supplied with the benchmarks.

    Includes node * weight, and positive e*tau*node*E/hbar shift.
    Do not replace with the separate negative-shift helper in the repository.
    """
    n1, n2 = energy_J.shape
    q = np.stack(np.meshgrid(np.arange(n1)/n1, np.arange(n2)/n2,
                            indexing='ij'), axis=-1)
    nodes, weights = np.polynomial.laguerre.laggauss(order)
    raw = np.zeros((2, 2))
    inverse = np.linalg.inv(basis_per_m)
    for node, weight in zip(nodes, weights):
        shift = (E_CHARGE * tau * float(node) / HBAR) * field
        qs = q + np.einsum('...i,ij->...j', shift, inverse)
        fs = fermi_window(sample(energy_J, qs), mu, temperature)
        vs = np.stack([sample(v[..., beta], qs) for beta in range(2)], axis=-1)
        raw += float(weight * node) * np.einsum('ija,ijb,ij->ab', v, vs, fs)
    area = abs(float(np.linalg.det(basis_per_m))) / (n1*n2)
    prefactor = SPIN * E_CHARGE**2 * tau / ((2*np.pi)**2 * KB * temperature)
    return prefactor * (raw * area)


class Package:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.units = read_json(self.folder / 'units_context.json')
        self.dimensions = read_json(self.folder / 'dimensions.json')
        for base in ('length', 'energy', 'time', 'charge', 'temperature'):
            scale = float(self.units[base]['scale_to_si'])
            if not math.isfinite(scale) or scale <= 0:
                raise ValueError(f'Invalid unit scale: {base}')
        payload = read_json(self.folder / 'vincent_epsilon_all_bands.json')
        if payload['schema'] != 'dft_local.benchmark.epsilon.v2':
            raise ValueError('Requires corrected benchmark epsilon schema v2; rebuild the package first')
        self.check_links(payload)
        r = payload['grid_definition']['reciprocal_vectors']
        for key in ('b1', 'b2'):
            if payload['dimensions'][key] != 'WAVEVECTOR':
                raise ValueError(f'{key} must be a WAVEVECTOR')
        if payload['dimensions']['bands'] != 'ENERGY':
            raise ValueError('bands must have ENERGY dimension')
        self.basis = np.asarray([r['b1'], r['b2']], dtype=float) * self.scale('WAVEVECTOR')
        if self.basis.shape != (2, 2) or not np.isfinite(self.basis).all():
            raise ValueError('Invalid reciprocal basis')
        if np.linalg.det(self.basis) == 0:
            raise ValueError('Singular reciprocal basis')
        self.grids = {}
        for block in payload['data']:
            n = int(block['grid_size'])
            bands = np.asarray(block['bands'], dtype=float)
            if n in self.grids or bands.ndim != 3 or bands.shape[1:] != (n, n):
                raise ValueError(f'Duplicate or invalid grid N={n}')
            if list(bands.shape) != block['bands_shape'] or not np.isfinite(bands).all():
                raise ValueError(f'Invalid band data N={n}')
            if bands.shape[0] == 0:
                raise ValueError('No bands supplied')
            self.grids[n] = bands
        self.cache = {}
        self.velocity_cache = {}

    def check_links(self, payload):
        if (payload['dimension_registry'] != 'dimensions.json'
                or payload['unit_context'] != 'units_context.json'):
            raise ValueError('Unexpected package unit/dimension files')

    def scale(self, dimension):
        return math.prod(float(self.units[base]['scale_to_si'])**power
                         for base, power in self.dimensions[dimension].items())

    def runs(self, name):
        payload = read_json(self.folder / f'conductivity_{name}.json')
        self.check_links(payload)
        if payload['schema'] != 'dft_local.benchmark.conductivity_runs.v1':
            raise ValueError('Unsupported run schema')
        required = dict(field='ELECTRIC_FIELD', tau='TIME', mu='ENERGY', temperature='TEMPERATURE')
        if any(payload['dimensions'][k] != v for k, v in required.items()):
            raise ValueError('Unexpected run dimensions')
        runs = payload['runs']
        if not runs or len({r['label'] for r in runs}) != len(runs):
            raise ValueError(f'Empty runs or duplicate labels in {name}')
        return runs

    def calculate(self, run, order):
        n = int(run['N'])
        field = np.asarray(run['field'], dtype=float) * self.scale('ELECTRIC_FIELD')
        mu = float(run['mu']) * self.scale('ENERGY')
        temp = float(run['temperature']) * self.scale('TEMPERATURE')
        tau = float(run['tau']) * self.scale('TIME')
        if field.shape != (2,) or not np.isfinite(field).all():
            raise ValueError('Invalid electric field')
        if not all(map(math.isfinite, [mu, temp, tau])) or temp <= 0 or tau < 0:
            raise ValueError('Requires finite parameters, T > 0 and tau >= 0')
        key = (n, *field, mu, temp, tau, order)
        if key not in self.cache:
            energies = self.grids[n] * self.scale('ENERGY')
            if n not in self.velocity_cache:
                self.velocity_cache[n] = [velocity(e, self.basis) for e in energies]
            sigma = np.zeros((2, 2))
            for e, v in zip(energies, self.velocity_cache[n]):
                sigma += conductivity_band(e, v, self.basis, mu, temp, tau, field, order)
            self.cache[key] = sigma / self.scale('SHEET_CONDUCTANCE')
        sigma = self.cache[key]
        out = {k: run[k] for k in ('label', 'N', 'field', 'mu', 'temperature', 'tau')}
        out.update(sigma=sigma.tolist(), trace=float(np.trace(sigma)))
        if PROFILE == 1:
            unnormalized = sigma * (2*np.pi)**2
            out.update(sigma_without_2pi_denominator=unnormalized.tolist(),
                       trace_without_2pi_denominator=float(np.trace(unnormalized)))
        print(f"{run['label']}: trace = {out['trace'] * self.scale('SHEET_CONDUCTANCE'):.12g} S", flush=True)
        return out


def compute(package, order):
    reference_runs = package.runs('reference')
    if len(reference_runs) != 1:
        raise ValueError('Expected exactly one reference run')
    result = dict(
        schema=f'dft_local.benchmark_package_{PROFILE}',
        dimension_registry='dimensions.json', unit_context='units_context.json',
        dimensions=EXPECTED_DIMENSIONS,
        conventions=dict(
            reciprocal_basis='b1 and b2 are Cartesian reciprocal vectors; B = np.stack([b1, b2]); k_cart = q @ B; a_i dot b_j = 2 pi delta_ij in matching units',
            spin_degeneracy=SPIN, primary_k_space_measure='d^2 k / (2 pi)^2'),
        reference=package.calculate(reference_runs[0], order),
    )
    groups = ['grid_zero_field'] if PROFILE == 1 else ['field_magnitude_x', 'field_magnitude_diagonal', 'grid_finite_field']
    for group in groups:
        runs = package.runs(group)
        if group.startswith('grid_'):
            runs = sorted(runs, key=lambda r: r['N'])
        result[group] = [package.calculate(r, order) for r in runs]
    if PROFILE == 1:
        rows = []
        sizes = sorted(package.grids)
        for coarse_n in sizes:
            for fine_n in sizes:
                if fine_n <= coarse_n or fine_n % coarse_n:
                    continue
                stride = fine_n // coarse_n
                coarse = package.grids[coarse_n]
                fine = package.grids[fine_n][:, ::stride, ::stride]
                if coarse.shape != fine.shape:
                    raise ValueError('Band/grid shape mismatch in shared-grid comparison')
                d = fine - coarse
                rows.append(dict(coarse_N=coarse_n, fine_N=fine_n,
                                 rms_error=float(np.sqrt(np.mean(d**2))),
                                 max_abs_error=float(np.max(np.abs(d)))))
        result['energy_grid_consistency'] = rows
        ref = reference_runs[0]
        result['band0_fermi_window_convergence'] = []
        for n in sizes:
            w = fermi_window(package.grids[n][0] * package.scale('ENERGY'),
                             ref['mu'] * package.scale('ENERGY'),
                             ref['temperature'] * package.scale('TEMPERATURE'))
            result['band0_fermi_window_convergence'].append(dict(
                N=n, band=0, mean_f_1_minus_f=float(w.mean()),
                sum_f_1_minus_f=float(w.sum()), max_f_1_minus_f=float(w.max())))
    return result




def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def input_names():
    groups = ['reference', 'grid_zero_field'] if PROFILE == 1 else [
        'reference', 'field_magnitude_x', 'field_magnitude_diagonal', 'grid_finite_field']
    return ['dimensions.json', 'units_context.json', 'vincent_epsilon_all_bands.json',
            *[f'conductivity_{g}.json' for g in groups]]




def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', nargs='?', type=Path, default=Path.cwd())
    parser.add_argument('--laguerre-order', type=int, default=48)
    args = parser.parse_args()
    if not 1 <= args.laguerre_order <= 128:
        parser.error('Require 1 <= order <= 128')
    folder = args.package
    package = Package(folder)
    inputs = input_names()
    if (folder / 'build_provenance.json').is_file():
        inputs.append('build_provenance.json')
    hashes = {name: digest(folder / name) for name in inputs}
    actual = compute(package, args.laguerre_order)
    if any(digest(folder / name) != value for name, value in hashes.items()):
        raise ValueError('Package inputs changed during computation')
    # Invalidate an old manifest before replacing any finalized output.
    (folder / 'SHA256SUMS').unlink(missing_ok=True)
    (folder / 'comparison_report.json').unlink(missing_ok=True)
    write_json(folder / 'expected_results.json', actual)
    write_json(folder / 'calculation_metadata.json', dict(
        package_profile=PROFILE, laguerre_order=args.laguerre_order,
        spin_degeneracy=SPIN, numpy_version=np.__version__,
        input_sha256=hashes, calculator_sha256=digest(Path(__file__)),
        electron_charge_C=E_CHARGE, hbar_J_s=HBAR, boltzmann_J_K=KB,
        method='periodic central differences; Eq. 8.30 positive shift; Laguerre weight*node',
    ))
    names = inputs + ['expected_results.json', 'calculation_metadata.json']
    for name in ('README.md', f'compute_package_{PROFILE}.py', 'compare_package.py'):
        if (folder / name).is_file():
            names.append(name)
    (folder / 'SHA256SUMS').write_text(''.join(
        f'{digest(folder / name)}  {name}\n' for name in names))
    print(f'Finalized {folder}: expected_results.json and SHA256SUMS written')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError, TypeError) as exc:
        print(f'Error: {exc}', file=sys.stderr)
        raise SystemExit(2)
