# Benchmark package 2

Inputs were exported by build_package_2.py. To generate the reference and
finalize checksums, run from this folder:

    python compute_package_2.py

Requires Python 3.10+ and NumPy; no dft_local dependency for computation.
This writes expected_results.json and calculation_metadata.json, then SHA256SUMS.
Do not distribute as a finalized benchmark until this finishes successfully.

For Vincent: use the energy grids, unit context and conductivity run files.
Export your results with the same JSON structure and package-native units as
expected_results.json, in a separate vincent_results.json file. Preserve labels,
run parameters, dimensions and schema. Run order may differ: comparison matches
labels (and grid diagnostics by grid sizes). Missing/duplicate/extra runs fail.
Then use the separate comparator without recomputing the reference:

    python compare_package.py . vincent_results.json

The comparison verifies checksums, writes comparison_report.json, and returns
0 for pass, 1 for numerical/structural mismatch, 2 for invalid inputs.
A full reference-shaped result file is required, including package 1 diagnostics.

b1 and b2 are complete Cartesian vectors; B = np.stack([b1,b2]); k = q @ B.
The epsilon schema is dft_local.benchmark.epsilon.v2. Resolve every numerical
unit using dimensions.json and units_context.json. Conductivity is sheet
conductance, whose SI unit is S. Preserve recorded unit scales exactly.

The calculator sums all bands with spin factor 1. It uses periodic central
velocity differences, periodic bilinear interpolation and the supplied Eq. 8.30
positive field shift with Gauss-Laguerre weight*node, default order 48.
--laguerre-order can override the order when generating the reference.
Comparison defaults: rtol=1e-7, absolute conductivity tolerance 1e-12 S,
energy tolerance 1e-30 J, others 1e-12 SI. Run parameters use rtol=1e-12
and no absolute tolerance. --rtol changes the result relative tolerance.

Recomputing replaces expected_results.json and finalizes new checksums. Keep the
reference fixed while comparing independent implementations. Comparison reports
and Vincent output are not included in the checksum manifest.

Console output is also supported, with an explicit unit and series selection:

    python compare_package.py . vincent_results.txt --series field_magnitude_x --text-unit S

Console comparison covers TOTAL tensors and trace only; the report lists
unverified parameters and diagnostics. Numerical print rounding is accounted for.
The comparator uses only Python and NumPy. It works with either package.

Build provenance is recorded in build_provenance.json. It links the exact
source energy export and selected live Python run definitions to the packaged
inputs. Compute includes this sidecar in calculation metadata and SHA256SUMS.
Root run JSON snapshots are not inputs to the builder. Energy export is an
explicit, separate stage; rebuilding sweeps reuses the selected energy file.
